from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ApplicationBuilder, CommandHandler, ContextTypes, CallbackQueryHandler

import os
TOKEN = os.getenv("TOKEN")  # Токен берётся из переменной окружения

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    keyboard = [
        [InlineKeyboardButton("Поиск билета", callback_data='search')],
        [InlineKeyboardButton("Спецпредложения", callback_data='offers')],
        [InlineKeyboardButton("Поддержка", callback_data='support')]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    await update.message.reply_text("Добро пожаловать в Airest Travel!\nВыберите действие:", reply_markup=reply_markup)

async def button_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    data = query.data

    if data == 'search':
        await query.edit_message_text(text="Введите маршрут в формате: Город1 - Город2")
    elif data == 'offers':
        await query.edit_message_text(text="Спецпредложения:\n• Москва — Дубай от 8 900₽\n• СПб — Тбилиси от 6 400₽")
    elif data == 'support':
        await query.edit_message_text(text="Напишите нам на support@airest.travel или в Telegram: @airest_support_bot")

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Доступные команды:\n/start — Главное меню\n/help — Помощь")

app = ApplicationBuilder().token(TOKEN).build()
app.add_handler(CommandHandler("start", start))
app.add_handler(CommandHandler("help", help_command))
app.add_handler(CallbackQueryHandler(button_handler))

print("Бот запущен...")
app.run_polling()