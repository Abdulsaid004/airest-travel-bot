ИНСТРУКЦИЯ ПО ЗАПУСКУ БОТА AIREST TRAVEL НА RENDER.COM

1. Создайте аккаунт на https://github.com и https://render.com

2. На GitHub:
   - Создайте новый репозиторий (назовите: airest-travel-bot)
   - Загрузите все файлы из этой папки (airest_travel_bot.py, requirements.txt, render.yaml)

3. На Render:
   - Нажмите "New Web Service"
   - Выберите свой GitHub-репозиторий
   - Укажите Environment: Python 3
   - В Start command: python airest_travel_bot.py
   - Добавьте переменную окружения: TOKEN = (ваш токен от BotFather)

4. Нажмите Deploy и бот заработает!

Проверьте в Telegram, отправив команду /start своему боту.